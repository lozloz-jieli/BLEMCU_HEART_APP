//
//  UpdateVC.h
//  OTA_Update
//
//  Created by DFung on 2019/8/21.
//  Copyright © 2019 DFung. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <DFUnits/DFUnits.h>
#import <JL_BLEKit/JL_BLEKit.h>


NS_ASSUME_NONNULL_BEGIN

@interface UpdateVC : UIViewController

@end

NS_ASSUME_NONNULL_END
